vti_encoding:SR|utf8-nl
vti_author:SR|CRIBASMX\\arivera
vti_modifiedby:SR|CRIBASMX\\arivera
vti_timelastmodified:TR|26 Jan 2016 13:18:22 -0000
vti_timecreated:TR|26 Jan 2016 13:18:22 -0000
vti_cacheddtm:TX|26 Jan 2016 13:18:22 -0000
vti_filesize:IR|176
vti_extenderversion:SR|12.0.0.4518
vti_backlinkinfo:VX|index.html top/index.html
